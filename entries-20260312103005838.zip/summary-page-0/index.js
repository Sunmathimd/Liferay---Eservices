window["backNavigationHistory"] = [];

const registerLiferayForm = function(formId) {
	AUI().use("liferay-form", function(){		
		Liferay.Form.register({ id: formId });
	});
}

const preventFormSubmissionOnEnterPress = function(formId) {
	$("#" + formId).on("keypress", function (event) {
		const targetType = event.target.type;
		if (event.keyCode == 13 && targetType != 'submit' && targetType != 'button' && targetType != 'file' && targetType != 'textarea') {
			event.preventDefault();
		}
	});
}

const thereAreNoHiddenErrors = function(element) {
	let erroedElements = $(element).find('.govuk-form-group--error');
	let noHiddenError = false;
	$(erroedElements).each(function() {
		if ($(this).parents(".hide").length == 0) {
			noHiddenError = true;
			this.scrollIntoView({ behavior: "smooth", block: "center" });
			return false;
		}
	});
	return noHiddenError;
}

window.submittedFormData = {};

$( "#"+ fragmentEntryLinkNamespace +"db-form-container" ).on( "submitForm", function( event ) {
	event.preventDefault();
	if (configuration.displayLoadingAnimation) {
		$("#" + fragmentEntryLinkNamespace + "loadingAnimation").removeClass("hide");
	}
 	var body = {};
	window.submittedFormData = {};
	
	$(this).find('.dp-form-condition').each(function( index ) {
		$( this ).trigger('change');
	});
 	$(this).find('[data-object-field]').each(function( index ) {
 		if( $( this ).parents('.hide:not(.form-container-page)').length > 0) {
			$( this ).val('');
			return; 
		}
 		let objectType = $( this ).attr('data-object-type');
		if(!$( "#"+ fragmentEntryLinkNamespace +"triggerBlurEvent").val() && $(this).parents(".hide").length == 0) {
			if (objectType == "date") {
				$( this ).parent().find(".govuk-date-input__input").trigger('blur');
			} else {
				$( this ).trigger('blur');
			}
		}
 		let objectField = $( this ).attr('data-object-field');
		let objectValue = sanitize($( this ).val());
		
		let fieldLabel = $(this).closest('.govuk-form-group').find('label').first().text().trim() || 
		                $(this).attr('placeholder') || 
		                $(this).attr('data-label') ||
		                objectField.replace(/([A-Z])/g, ' $1').trim(); // Convert camelCase to Title Case
		
		if (objectValue && objectValue.trim() !== '') {
			window.submittedFormData[objectField] = {
				label: fieldLabel,
				value: objectValue,
				type: objectType
			};
		}		
		if (objectType == "checkbox") {
			let checkboxValues = objectValue.split(",");
			body[objectField] = checkboxValues.map(str => str.trim());
		} else if (objectType == "file") {
    let fileData = $( this ).val();
    if (fileData) {
        let fileField = {};	
        fileData = fileData.substring(fileData.indexOf(',') + 1);
        fileField["fileBase64"] = fileData;
        fileField["name"] = this.dataset.fileName;
        body[objectField] = fileField;
        
        window.submittedFormData[objectField] = {
            label: fieldLabel,
            value: this.dataset.fileName || 'File uploaded',
            type: objectType
        };
    }
}

else if (objectType == "enquiryDocument" || objectType == "enquiryAddress") {

		} else if (objectType == "richText") {
			body[objectField] = $( this ).val();
		} else {
			body[objectField] = objectValue;
		}
	});
 	if (thereAreNoHiddenErrors($(this))) {
		event.preventDefault();
		if (configuration.displayLoadingAnimation) {
			$("#" + fragmentEntryLinkNamespace + "loadingAnimation").addClass("hide");
		}
		return false;
	}
 	let restContextPath = $('#'+ fragmentEntryLinkNamespace +'restContextPath').val();
	let objectEntryId = $('#'+ fragmentEntryLinkNamespace +'objectEntryId').val();
	let objectDefinitionId = $('#'+ fragmentEntryLinkNamespace +'objectDefinitionId').val();
	let objectEntryERC = $('#'+ fragmentEntryLinkNamespace +'objectEntryERC').val();
	let scope = $('#'+ fragmentEntryLinkNamespace +'scope').val();
	let method = 'POST';
 	let url = configuration.postEndpointURL;
 	if(!url){
		url = '/o' + restContextPath;
		if (objectEntryId) {
			url = url + '/' + objectEntryId;
			method = 'PATCH';
		} else if (scope == 'site') {
			url = url + '/scopes/' + Liferay.ThemeDisplay.getScopeGroupId();
		}
	} else if(objectEntryERC) {
		url =  url.replace('{objectDefinitionId}', objectDefinitionId).replace('{objectEntryERC}', objectEntryERC);
		method = 'POST';
	}
	
	var buttonRedirectUrl = this.buttonRedirectUrl;
	var formContainer = $(this);
	
	(async () => {
		try {
  		const response = await fetch(url, {
				headers: {
					"Content-Type": "application/json",
					"x-csrf-token": Liferay?.authToken || ''
				},
				method: method,
				body: JSON.stringify(body)
			});
			
			if (!response.ok) {
				throw new Error(`Network response was not ok: ${response.status}`);
			}
			
			const json = await response.json();
			const $this = $(this);
			const elements = $this.find('[data-event-post-object-creation]');
			const totalEvents = elements?.length || 0;
			console.debug(`data-event-post-object-creation events found: ${totalEvents}`);
			
			if (totalEvents > 0) {
				let promises = [];
				for (const element of Array.from(elements)) {
					// Fallback for CustomEvent support
					let event;
					try {
						event = new CustomEvent("postObjectEntryCreate", { detail: json });
					} catch (e) {
						event = document.createEvent('CustomEvent');
						event.initCustomEvent("postObjectEntryCreate", true, true, json);
					}
					let promise = new Promise((resolve) => {
						element.addEventListener("postObjectEntryCreateEventComplete", () => {
							console.debug("postObjectEntryCreateEventComplete");
							resolve();
						}, { once: true });
						element.dispatchEvent(event);
					});
					promises.push(promise);
				}
				Promise.all(promises).then(async (values) => { 
					console.debug("All postObjectEntryCreateEventComplete");
					if (configuration.afterPostEventsCompletedAction) {
						await executeObjectAction(objectDefinitionId, json.externalReferenceCode, configuration.afterPostEventsCompletedAction);	
					}
					processFormContainerPostCreationActions(buttonRedirectUrl, $(formContainer).attr('data-custom-events-redirect') || '', json); 
				});
			} else {
				processFormContainerPostCreationActions(buttonRedirectUrl, '', json);
			}
		} catch (error) {
		  console.error(error);
		  if (configuration.displayLoadingAnimation) {
				$("#" + fragmentEntryLinkNamespace + "loadingAnimation").addClass("hide");
			}
		}
	})();
	return false;
});

function processFormContainerPostCreationActions(buttonRedirectUrlValue, customEventsRedirect, json){
	var formContainerDefaultRedirectURL = buttonRedirectUrlValue ? buttonRedirectUrlValue : $('#'+ fragmentEntryLinkNamespace +'redirectURL').val();
	var redirectUrl = customEventsRedirect ? customEventsRedirect : formContainerDefaultRedirectURL;
	var paramCheck = redirectUrl.match(/\{([^}]+)\}/);
 	if (paramCheck) {
		var paramName = paramCheck[1];
		const urlParams = new URLSearchParams(window.location.search);
		if (paramName === 'objectEntryId') {
			redirectUrl = redirectUrl.replace('{objectEntryId}', json.id);
		} else if (json[paramName]) {
			redirectUrl = redirectUrl.replace('{' + paramName +'}', json[paramName]);
		} else if (urlParams.has(paramName)) {
			redirectUrl = redirectUrl.replace('{' + paramName +'}', urlParams.get(paramName));
		}
 		var propertyId = $('#'+ fragmentEntryLinkNamespace +'propertyId').val();
		if(redirectUrl.includes("propertyId")) {
			if (propertyId) {
				redirectUrl = redirectUrl.replace('{propertyId}', propertyId) 
			} else {
				redirectUrl = redirectUrl.replace('&propertyId={propertyId}', "") 
			}
		}
	}
	console.debug('redirectUrl: ' + redirectUrl);
 	if (configuration.closePopupOnSave){
		parent.closePopup(json.id);
	} else if (configuration.isRedirectEnabled && redirectUrl) {
		window.location.href = redirectUrl;
	} else {

		$('.form-container-page').addClass('hide');

		let confBody = $('.form-confirmation-page').html();

		confBody = confBody.replaceAll('{objectEntryId}', json.id);

		Object.keys(json).forEach(function(key) {
			confBody = confBody.replaceAll('{' + key + '}', json[key]);
		});

		console.debug(confBody);

		$('.form-confirmation-page').html(confBody);
	
		$('.form-confirmation-page').removeClass('hide');
		
		if (configuration.displayLoadingAnimation) {
			$("#" + fragmentEntryLinkNamespace + "loadingAnimation").addClass("hide");
		}
	}
}
 
function sanitize(string) {
	const map = {
	  '&': '&amp;',
		'<': '&lt;',
		'>': '&gt;',
		'"': '&quot;',
		"'": '&#39;',
		'/': '&#x2F;',
		'`': '&#x60;',
		'=': '&#x3D;'
	};
	const reg = /[&<>"'/]/ig;
	return string.replace(reg, (match)=>(map[match]));
}
 
$( "#"+ fragmentEntryLinkNamespace +"db-form-container .form-container-next-button" ).on( "click", function( event ) {
	var dataObjectFields = document.querySelectorAll('[data-object-field]:not(.dp-hidden-field)');
 
	for (let dataObjectField of dataObjectFields) {
		let objectFieldName = dataObjectField.dataset.objectField;
		if (objectFieldName) {
			let objectFieldValue = dataObjectField.value;
 
			try {
				window[objectFieldName] = objectFieldValue.replace(/(\r\n|\n|\r)/gm, "");
			}
			catch (e) {
				console.error("Error when evalueting field:" + objectFieldName + ", with value: " + objectFieldValue + ". Error: " + e)
				event.preventDefault();
			}
		}
	}
 
	$(this).parent().find('[data-object-field]').each(function( index ) {
		if ($(this).parents(".hide").length == 0) {
			$(this).trigger('blur');
		}
	});
 
	$(this).parent().find('.govuk-date-input__input.date-form-field').each(function( index ) {
		if ($(this).parents(".hide").length == 0) {
			$(this).trigger('blur');
		}
	});
 
	if (thereAreNoHiddenErrors($(this).parent())) {
		event.preventDefault();
		return;
	}
 
	let page = $(this).closest('.form-container-page');
	let nextPageId = $(page).data("redirect-page");
 
	if (!nextPageId) {
		$(this).parent().find('.page-rule-fragment').each(function () {
			var $dataObjectField = $(this);
 
			var expressionValue = $dataObjectField.find('input[name$="expression"]').val();
			var targetPage = $dataObjectField.find('input[name$="targetPage"]').val();
 
			if (expressionValue && targetPage && eval(expressionValue)) {
				nextPageId = targetPage;
				return;
			}
		});
	} else {
		$(page).removeAttr("data-redirect-page");
	}
 
	if (nextPageId) {
		$('.form-container-page').addClass('hide');
		let nextPage = $('.form-container-page[data-page-name="' + nextPageId + '"]');
		if (nextPage.length == 0) {
			nextPage = $('.form-container-page[data-form-page="' + nextPageId + '"]');
		}
 
		$(nextPage).removeClass('hide');
		$(nextPage)[0].scrollIntoView();
	}
	else {
		let getNextItem = false;
		let formContainer = $(this).parent();
		$(this).closest(".dp-form-container").find(".form-container-page").each(function (index, item) {
			if ($(item).attr("id") === $(formContainer).attr("id")) {
				getNextItem = true;
			}
			else if (getNextItem) {
				$(formContainer).addClass('hide');
				$(item).removeClass('hide');
				$(item)[0].scrollIntoView();
 
				return false;
			}
		});
	}
 
	backNavigationHistory.push("#" + $(this).closest('.form-container-page').attr("id"));
 
	event.preventDefault();
});
 
$( "#"+ fragmentEntryLinkNamespace +"db-form-container .form-container-back-link" ).on( "click", function( event ) {
	if(backNavigationHistory.length > 0) {
		let prevPageSelector = backNavigationHistory.pop();
 
		$('.form-container-page').addClass('hide');
		$(prevPageSelector).removeClass('hide');
	}
 
	event.preventDefault();
});
 
let itemsWithoutDataPageName = 0;

$("#"+ fragmentEntryLinkNamespace +"db-form-container .form-container-page").each(function(index) {
	if (document.body.classList.contains('has-edit-mode-menu')) {
		return;
	}
 
	if(!$(this).attr('data-page-name')) {
		$(this).attr('data-form-page', itemsWithoutDataPageName++);
	}
 
	if (index === 0) {
		$(this).find('.form-container-back-link').addClass('hide');
	}
	if (index > 0) {
		$(this).addClass('hide');
	}
});
 
$( "#"+ fragmentEntryLinkNamespace +"object-definition-select" ).on( "change", function( event ) {
 
	Liferay.Service(
	'/expandovalue/add-value',
		{
			companyId: Liferay.ThemeDisplay.getCompanyId(),
			className: 'com.liferay.portal.kernel.model.Layout',
			tableName: 'CUSTOM_FIELDS',
			columnName: 'objectDefinitionId',
			classPK: Liferay.ThemeDisplay.getPlid(),
			data: this.value
		},
		function(obj) {
			console.debug(obj);
			location.reload();
		}
	);
});
 
async function executeObjectAction(objectDefinitionId, objectEntryErc, actionName) {
	const url = `/o/dp-headless-object/v1.0/execute-object-action/${objectDefinitionId}/${actionName}/${objectEntryErc}`;
 
	try {
		const response = await fetch(url, {
			headers: {
				"Content-Type": "application/json",
				"x-csrf-token": Liferay.authToken
			},
			body: "{}",
			method: "POST"
		});
 
		if (!response.ok) {
			throw new Error(`Failed to execute action ${actionName} on object ${objectEntryErc}: ${response.status}`);
		}
 
	} catch (error) {
		console.error('Error executing action: ', error);
	}
}
 
$(document).ready(function () {
	let form = $("#" + fragmentEntryLinkNamespace + "db-form-container");
	if (form) {
		let formId = $(form).attr("id");
		registerLiferayForm(formId);
		preventFormSubmissionOnEnterPress(formId);
	}
});

(function () {
    function decodeHtmlEntities(text) {
        if (!text) return "";
        const txt = document.createElement("textarea");
        txt.innerHTML = text;
        return txt.value;
    }

    const loadJsPDF = () => {
        return new Promise((resolve) => {
            if (window.jspdf) {
                resolve();
                return;
            }
            const script = document.createElement("script");
            script.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";
            script.onload = resolve;
            document.head.appendChild(script);
        });
    };

    async function downloadApplicationPDF() {
        try {
            await loadJsPDF();
            const { jsPDF } = window.jspdf;
            const referenceIdEl = document.querySelector(".reference-id");
            if (!referenceIdEl) {
                alert("Reference ID not available");
                return;
            }
            const referenceId = decodeHtmlEntities(referenceIdEl.innerText.trim());

            const pdf = new jsPDF("p", "mm", "a4");
            const pageWidth = pdf.internal.pageSize.getWidth();
            const pageHeight = pdf.internal.pageSize.getHeight();
            const margin = 20;
            let y = 20;
   
            pdf.setFontSize(20);
            pdf.setFont(undefined, 'bold');
            pdf.text("Application Summary", pageWidth / 2, y, { align: "center" });
            y += 15;
        
            pdf.setFillColor(232, 240, 255); 
            pdf.rect(margin, y - 5, pageWidth - 2 * margin, 20, 'F');
            
            pdf.setFontSize(11);
            pdf.setFont(undefined, 'normal');
            pdf.text("Reference ID", pageWidth / 2, y + 3, { align: "center" });
            
            pdf.setFontSize(16);
            pdf.setFont(undefined, 'bold');
            pdf.setTextColor(37, 99, 235); 
            pdf.text(referenceId, pageWidth / 2, y + 11, { align: "center" });
            pdf.setTextColor(0, 0, 0); 
            
            y += 30;
            pdf.setFontSize(10);
            pdf.setFont(undefined, 'normal');
            pdf.text(`Submitted: ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}`, margin, y);
            y += 15;         
            pdf.setDrawColor(209, 213, 219);
            pdf.line(margin, y, pageWidth - margin, y);
            y += 10;
          
            pdf.setFontSize(14);
            pdf.setFont(undefined, 'bold');
            pdf.text("Application Details", margin, y);
            y += 10;

            pdf.setFontSize(10);
            pdf.setFont(undefined, 'normal');

if (window.submittedFormData && Object.keys(window.submittedFormData).length > 0) {

    const labelX = margin;
    const valueX = margin + 60; // fixed value column
    const valueWidth = pageWidth - valueX - margin;
    const lineHeight = 6;
    const rowGap = 8;

    Object.entries(window.submittedFormData).forEach(([field, data]) => {

        if (y > pageHeight - 25) {
            pdf.addPage();
            y = 20;
        }
    
        pdf.setFont(undefined, 'bold');
        pdf.text(data.label + ":", labelX, y);
        pdf.setFont(undefined, 'normal');
        //const valueText = decodeHtmlEntities(String(data.value || "-"));
        //const wrappedLines = pdf.splitTextToSize(valueText, valueWidth);			

let valueText = "-";

if (data.type === 'file') {
      valueText = data.value || "File uploaded";
} else if (data.value && data.value.toString().trim()) {
    valueText = decodeHtmlEntities(String(data.value));
} else {
    valueText = "-";
}

const wrappedLines = pdf.splitTextToSize(valueText, valueWidth);


        wrappedLines.forEach((line, index) => {
            if (y > pageHeight - 25) {
                pdf.addPage();
                y = 20;
            }
            pdf.text(line, valueX, y);
            if (index < wrappedLines.length - 1) {
                y += lineHeight;
            }
        });

        y += rowGap;
    });
}
          
           if (y > pageHeight - 50) {
                pdf.addPage();
                y = 20;
            }
            
            y += 10;
            pdf.setDrawColor(209, 213, 219);
            pdf.line(margin, y, pageWidth - margin, y);
            y += 8;

            pdf.setFontSize(9);
            pdf.setFont(undefined, 'italic');
            pdf.text("Please keep this document for your records.", margin, y);

				pdf.save(`Application_${referenceId}.pdf`);
        } catch (e) {
            console.error("PDF download failed:", e);
            alert("Failed to generate PDF. Please try again.");
        }
    }

function printApplication() {
    const referenceIdEl = document.querySelector(".reference-id");

    if (!referenceIdEl) {
        alert("Reference ID not available");
        return;
    }

    const referenceId = referenceIdEl.innerText.trim();

    const printWindow = window.open('', '', 'noopener,noreferrer,width=1200,height=1400');

    const printHTML = `
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Application Summary - ${referenceId}</title>
<style>
    * { box-sizing: border-box; }
    body {
        font-family: Arial, sans-serif;
        padding: 10mm;
        color: #111;
    }
    .container {
        max-width: 190mm;
        margin: 0 auto;
        text-align: center;
    }
    .success-icon {
        font-size: 48px;
        color: #22c55e;
        margin-bottom: 10px;
    }
    h1 { font-size: 22px; margin-bottom: 6px; }
    p { font-size: 14px; color: #555; }
    .reference-card {
        margin: 20px 0;
        padding: 15px;
        background: #e8f0ff;
        border-radius: 6px;
    }
    .reference-id {
        font-size: 22px;
        font-weight: bold;
        color: #2563eb;
        letter-spacing: 2px;
    }
    .next-steps {
        text-align: left;
        margin-top: 20px;
    }
    @page {
        size: A4;
        margin: 10mm;
    }
</style>
</head>
<body>
    <div class="container">
        <div class="success-icon">✓</div>
        <h1>Application Submitted Successfully!</h1>
        <p>Your application has been received and is now being processed.</p>

        <div class="reference-card">
            <div>Reference ID</div>
            <div class="reference-id">${referenceId}</div>
        </div>

        <div class="next-steps">
            <h3>Next Steps</h3>
            <ol>
                <li>Your application will be reviewed by our team</li>
                <li>You will receive email/SMS updates on progress</li>
                <li>Track your application using the Reference ID</li>
            </ol>
        </div>
    </div>
</body>
</html>
`;

    printWindow.document.open();
    printWindow.document.write(printHTML);
    printWindow.document.close();

    printWindow.onload = function () {
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };
}
	
	document.addEventListener("DOMContentLoaded", function () {
    const printBtn = document.getElementById("printApplicationBtn");

    if (printBtn) {
        printBtn.addEventListener("click", printApplication);
    }
});
    function copyReferenceId() {
        const referenceIdEl = document.querySelector(".reference-id");
        if (!referenceIdEl) {
            alert("Reference ID not found");
            return;
        }
        
        const referenceId = referenceIdEl.innerText.trim();
        const btn = document.getElementById("copyRefBtn");
        

        navigator.clipboard.writeText(referenceId).then(() => {
            
            btn.textContent = "Reference ID Copied!";
            btn.classList.add("copied");
                       setTimeout(() => {
                btn.textContent = "Copy Reference ID";
                btn.classList.remove("copied");
            }, 2000);
        }).catch(err => {
            console.error("Failed to copy:", err);
                     try {
                const textarea = document.createElement('textarea');
                textarea.value = referenceId;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                
                btn.textContent = "Reference ID Copied!";
                btn.classList.add("copied");
                
                setTimeout(() => {
                    btn.textContent = "Copy Reference ID";
                    btn.classList.remove("copied");
                }, 2000);
            } catch (fallbackErr) {
                alert("Failed to copy Reference ID");
            }
        });
    }
    
    
    window.copyReferenceId = copyReferenceId;

        document.addEventListener("click", function (e) {
        if (e.target && e.target.id === "downloadPdfBtn") {
            e.preventDefault();
            downloadApplicationPDF();
        }
        if (e.target && e.target.id === "printApplicationBtn") {
            e.preventDefault();
            printApplication();
        }
    });
})();
console.log("JavaScript loaded");

setTimeout(function() {
    const copyBtn = document.getElementById('copyRefBtn');
    const referenceIdEl = document.querySelector('.reference-id');
    
    console.log("Copy button found:", copyBtn);
    console.log("Reference ID element found:", referenceIdEl);
    
    if (copyBtn) {
        copyBtn.addEventListener('click', function() {
            console.log("Button clicked!");
            alert("Button was clicked!");
            
            copyBtn.textContent = 'Reference ID Copied!';
            copyBtn.style.background = '#10b981';
            copyBtn.style.color = 'white';
            
            setTimeout(() => {
                copyBtn.textContent = 'Copy Reference ID';
                copyBtn.style.background = '#ffffff';
                copyBtn.style.color = 'black';
            }, 2000);
        });
    } else {
        console.error("Copy button NOT found!");
    }
}, 1000);