const isAddressChildFieldWrapper = function(wrapperId) {

	return wrapperId.match(/(\w*)address-(\w+)-wrapper/g);

};
 
const getInputFieldLabel = function(element) {

	let label = '';

	let parentFormGroup = $(element).parents(".govuk-form-group").first();

	let parentFormGroupId = $(parentFormGroup).attr("id");
 
	if (configuration.useDefaultObjectFieldLabel) {

		label = $(element).attr("data-object-field-label");

	}
 
	if (!label) {

		if (parentFormGroupId) {

			if (parentFormGroupId.endsWith("address-lookup-wrapper")) {

				label = $(parentFormGroup).find("label[data-lfr-editable-id]").html();

			} else if (parentFormGroupId.endsWith("radio-wrapper")) {

				label = $(parentFormGroup).find("legend").html();

			} else if (

				parentFormGroupId.endsWith("text-input-wrapper") ||

				isAddressChildFieldWrapper(parentFormGroupId) ||

				$(element).attr("type") === "file" ||

				parentFormGroupId.endsWith("select-wrapper") ||

				parentFormGroupId.endsWith("textarea-wrapper") ||

				parentFormGroupId.endsWith("date-wrapper")

			) {

				label = $(parentFormGroup).find("label").html();

			}

		}

	}
 
	return label || "unsupported-field";

};
 
$(document).ready(function() {
 
	let inputFields = [];

	let fieldsFromConfig = configuration.fieldsList || '';
 
	if (fieldsFromConfig.length > 0) {

		fieldsFromConfig.split(',').forEach(field => {

			inputFields.push($('[data-object-field="' + field + '"]'));

		});

	} else {

		inputFields = $('[data-object-field]');
 
		/* =====================================================

		   ✅ ADDITION (ONLY THIS PART IS NEW)

		   Include file upload inputs safely in summary

		   ===================================================== */

		const fileUploadInputs = $("input[type='file']");

		if (fileUploadInputs.length) {

			inputFields = inputFields.add(fileUploadInputs);

		}

	}
 
	let fieldSummaryObjects = [];
 
	for (const element of inputFields) {
 
		let parentFormGroup = $(element).parents(".govuk-form-group").first();

		let parentFormGroupId = $(parentFormGroup).attr("id");

		let value = $(element).val();
 
		if (parentFormGroupId) {

			if (parentFormGroupId.endsWith("address-lookup-wrapper")) {

				if (!$(element).attr("id").endsWith("address-fullAddress")) {

					continue;

				}

			}

			else if (parentFormGroupId.endsWith("radio-wrapper")) {

				let checked = $(parentFormGroup)

					.find(".govuk-radios__input:checked");

				value = checked.siblings(".govuk-radios__label").text();

			}

			else if (parentFormGroupId.endsWith("select-wrapper")) {

				value = $(parentFormGroup)

					.find("option:selected").text();

			}

		}
 
		/* ================= FILE UPLOAD VALUE FIX ================= */

		if ($(element).attr("type") === "file") {

			value =

				element.files && element.files[0]

					? element.files[0].name

					: '';

		}
 
		const label = getInputFieldLabel(element);
 
		let pageElement = $(element).parents('.form-container-page').first();

		let page =

			$(pageElement).attr('data-form-page') ||

			$(pageElement).attr('data-page-name');
 
		fieldSummaryObjects.push({

			value: value,

			input: $(element),

			label: label,

			page: page

		});

	}
 
	let summaryContainer =

		$('#' + fragmentEntryLinkNamespace + 'dp-form-summary');
 
	for (const element of fieldSummaryObjects) {
 
		let rowClass = element.value ? "" : "hide";
 
		$(summaryContainer).append(

			"<div class='govuk-summary-list__row " + rowClass +

			"' data-input-id='" + $(element.input).attr('id') + "'>" +

				"<dt class='govuk-summary-list__key'>" + element.label + "</dt>" +

				"<dd class='govuk-summary-list__value'>" + element.value + "</dd>" +

				"<dd class='govuk-summary-list__actions'>" +

					"<a class='govuk-link page-switch-link' " +

					"data-page-to-link-to='" + element.page + "' href='javascript:;'>Change</a>" +

				"</dd>" +

			"</div>"

		);
 
		let summaryRow =

			$(summaryContainer).find(

				"[data-input-id='" + $(element.input).attr('id') + "']"

			);
 
		/* ================= FILE UPLOAD LIVE UPDATE ================= */

		if ($(element.input).attr("type") === "file") {

			$(element.input).on("change", function (e) {

				const fileName =

					e.target.files && e.target.files[0]

						? e.target.files[0].name

						: '';
 
				$(summaryRow)

					.find(".govuk-summary-list__value")

					.html(fileName);
 
				fileName

					? $(summaryRow).removeClass("hide")

					: $(summaryRow).addClass("hide");

			});

		}
 
		/* ================= OTHER INPUTS ================= */

		else {

			$(element.input).on("blur change", function () {

				let val = $(this).val();

				$(summaryRow)

					.find(".govuk-summary-list__value")

					.html(val);
 
				val

					? $(summaryRow).removeClass("hide")

					: $(summaryRow).addClass("hide");

			});

		}

	}

});
 
/* ================= HELPERS (UNCHANGED) ================= */
 
const getAllObjectFieldValues = function(dataObjectFieldName) {

	let value = '';

	$("[data-object-field='" + dataObjectFieldName + "']").each(function() {

		if ($(this).parents(".hide").length === 0) {

			if (

				$(this).attr("type") === "file" &&

				this.files &&

				this.files.length > 0

			) {

				value += this.files[0].name + ",";

			}

			else if ($(this).val()) {

				value += $(this).val() + ",";

			}

		}

	});

	return value ? value.slice(0, -1) : '';

};
 
const formatDate = function(dateString) {

	try {

		return dateString

			? new Date(dateString).toLocaleDateString()

			: '';

	} catch (e) {

		return '';

	}

};
 
 